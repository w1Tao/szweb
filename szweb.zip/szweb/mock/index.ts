import type { MockMethod } from 'vite-plugin-mock';
// 模拟后端请求数据
const userData = [
    {
        username: 'admin',
        password: '123456'
    }
]
export default [
    {
        url: '/api/login',
        method: 'post',
        response: (data: any) => {
            const info = data.body;
            const result = userData.some(item => {
                return item.username === info.username && item.password === info.password;
            })
            const msg = result ? '登陆成功，欢迎${info.username}!' : '用户名或密码错误';
            return { msg };
        },
    },
] as MockMethod[];