// 创建利用axios向后端发送异步请求的service并导出
import axios from "axios";

const baseURL = '/';
const service = axios.create({
    baseURL,
    timeout: 5000 // 请求超时时间
});

export default service;