<template>
    <div class="center">
        <form action="/webdemo/login" method="post">
            <p style="margin-button: 50px">用户登录</p>
            <p>
                <label for="username">请输入账号：</label>
                <input type="text" id="username" v-model="username">
            </p>
            <p>
                <label for="password">请输入密码：</label>
                <input type="text" id="password" v-model="password">
            </p>
            <button @click.prevent="handleLogin">提交</button>
            <h2>{{ result }}</h2>
        </form>
    </div>
</template>

<script setup lang="ts">
import {ref} from 'vue';
import {login} from '@/api/user';

const username = ref('');
const password = ref('');
const result = ref('');
const handleLogin = async() =>{
    if(username.value === "||password.value ==="){
        alert("账号或密码不能为空")
    } else{
        try {
            const res = await login({username: username.value,password: password.value})
            result.value = res.data.msg
        }catch(e){
        alert(e)
        }
    }
}
</script>

<style scoped>
.center {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 600px;
    height: 300px;
    background-color: #f0f0f0;
}

div {
    box-shadow: 0px 0px 10px #888888;
}
</style>