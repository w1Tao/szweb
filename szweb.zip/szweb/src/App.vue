<script setup lang="ts">
import UserLogin from './components/UserLogin.vue';
</script>

<template>
  <UserLogin />
</template>

<style scoped>
</style>
