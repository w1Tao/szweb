//  该文件中使用service创建向后端发送访问用户数据请求的API，发送的请求会被Mock拦截从而返回模拟数据
import service from "@/utils/request";

export interface User {
    username: string,
    password: string
}

export function login(data: User) {
    return service({
        url: '/api/login',
        method: 'post',
        data: data,
    });
}